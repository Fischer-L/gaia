/* exported MockTonePlayer */

'use strict';

var MockTonePlayer = {
  init: function() {},
  playSequence: function() {},
  start: function(frequencies, shortPress) {},
  stop: function() {}
};
