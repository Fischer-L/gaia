'use strict';

var MockSearch = {
  init: function() {},
  invalidateCache: function() {},
  removeContact: function() {},
  search: function() {},
  enterSearchMode: function() {},
  exitSearchMode: function() {},
  isInSearchMode: function() {}
};
