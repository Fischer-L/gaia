'use strict';

var MockPerformanceTestingHelper = {
  dispatch: function() {}
};
