'use strict';

/* exported MockThumbnailImage */

var MockThumbnailImage = function(blob, callback) {
  callback(blob);
};
