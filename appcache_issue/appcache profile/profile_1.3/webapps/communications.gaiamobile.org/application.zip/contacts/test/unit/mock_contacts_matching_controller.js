'use strict';

var MockMatchingController = {
  merge: function(checkedContacts) {
    this.checkedContacts = checkedContacts;
  }
};
