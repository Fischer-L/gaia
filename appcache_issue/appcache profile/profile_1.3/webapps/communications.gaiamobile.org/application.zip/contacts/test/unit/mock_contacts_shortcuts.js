'use strict';

var MockAlphaScroll = {
  init: function(params) {
    return;
  },
  toggleFormat: function() {
    return;
  }
};
