'use strict';

var MockExtFb = {
  importFB: function() {},
  initEventHandlers: function(node, contact, linked) {}
};
