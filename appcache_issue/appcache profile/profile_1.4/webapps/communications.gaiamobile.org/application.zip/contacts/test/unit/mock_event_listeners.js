'use strict';

/* exported MockUtils */

var MockUtils = {
  listeners: {
    add: function() {}
  },
  cookie: {

  }
};
