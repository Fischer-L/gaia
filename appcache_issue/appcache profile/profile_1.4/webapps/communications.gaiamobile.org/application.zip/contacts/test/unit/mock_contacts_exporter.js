'use strict';
/* exported MockContactsExporter */

var MockContactsExporter = function() {
  return {
    'init': function(ids, cb) {},
    'setExportStrategy': function(st) {},
    'start': function() {}
  };
}();
