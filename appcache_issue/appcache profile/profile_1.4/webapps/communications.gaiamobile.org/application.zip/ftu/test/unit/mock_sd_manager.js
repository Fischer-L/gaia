'use strict';

var MockSdManager = {
  available: function() { return true; },
  checkSDButton: function() {},
  importContacts: function() {}
};
