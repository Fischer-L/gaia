'use strict';

/*
var ringer = function callsHandler() {
  var phoneSoundURL = new SettingsURL();
  SettingsListener.observe('dialer.ringtone', '', function(value) {
    ringtonePlayer.pause();
    ringtonePlayer.src = phoneSoundURL.set(value);
  });
  var ringtonePlayer = ringtonePlayer;
  ringtonePlayer = new Audio();
  ringtonePlayer.mozAudioChannelType = 'ringer';
  ringtonePlayer.src = phoneSoundURL.get();
  ringtonePlayer.loop = false;

  window.addEventListener('home', function (evt) {
    evt.preventDefault();
    ringtonePlayer.play();
  });
  window.addEventListener('click', function (evt) {
    evt.stopPropagation();
    ringtonePlayer.play();
  });
}();

*/
