/* global AppWindow */
/* exported appWindow */
'use strict';

var appWindow = new AppWindow();
