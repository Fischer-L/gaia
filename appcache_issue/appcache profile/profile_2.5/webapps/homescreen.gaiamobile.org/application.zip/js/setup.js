window.GaiaAppIconBaseurl = 'shared/elements/gaia-site-icon/';
