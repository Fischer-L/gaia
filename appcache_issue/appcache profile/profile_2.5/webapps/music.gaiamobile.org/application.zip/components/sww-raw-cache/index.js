var RawCache = require('./lib/sww-raw-cache.js');

self.RawCache = RawCache;
