/* global UI, Controller */

'use strict';

window.onload = function() {
  Controller.init();
  UI.init();
};
