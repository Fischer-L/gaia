/* global TelephonySettingHelper */
/**
 * The module loads scripts used by the root panel. In the future these scripts
 * must be converted to AMD modules. Implementation details please refer to
 * {@link Root}.
 *
 * @module root/root
 */
define('panels/root/root',['require','shared/lazy_loader'],function(require) {
  'use strict';

  var LazyLoader = require('shared/lazy_loader');

  /**
   * @alias module:root/root
   * @class Root
   * @requires module:shared/lazy_loader
   * @returns {Root}
   */
  function Root() {}

  Root.prototype = {
    _panel: null,
    _loadScripts: function root_loadScripts() {
      /**
       * Enable or disable the menu items related to the ICC card
       * relying on the card and radio state.
       */
      LazyLoader.load([
        'js/firefox_accounts/menu_loader.js',
        'js/dsds_settings.js',
        'js/telephony_settings.js',
        'js/telephony_items_handler.js'
      ], function() {
        TelephonySettingHelper
          .init()
          .then(function telephonySettingInitDone() {
            window.dispatchEvent(new CustomEvent('telephony-settings-loaded'));
          });
      });
    },

    /**
     * Update the sim related items based on mozMobileConnections.
     */
    _showSimItems: function root_showSimItems(panel) {
      var mozMobileConnections = navigator.mozMobileConnections;
      if (mozMobileConnections) {
        if (mozMobileConnections.length === 1) { // single sim
          var duelSimItem =
            this._panel.querySelector('#simCardManager-settings');
          duelSimItem.hidden = true;
        } else { // DSDS
          var simItem = this._panel.querySelector('#simSecurity-settings');
          simItem.hidden = true;
        }
      } else {
        // hide telephony panels
        var elements = ['#call-settings',
                        '#data-connectivity',
                        '#messaging-settings',
                        '#simSecurity-settings',
                        '#simCardManager-settings'];
        elements.forEach(el => {
          this._panel.querySelector(el).hidden = true;
        });
      }
    },
    /**
     * Update the developer menu item based on the preference.
     */
    _showDeveloperMenuItem: function root_showDeveloperMenuItem() {
      var developerItem = this._panel.querySelector(
        '[data-show-name="developer.menu.enabled"]');
      if (developerItem && navigator.mozSettings) {
        return navigator.mozSettings.createLock()
          .get('developer.menu.enabled').then(
            function(result) {
              developerItem.hidden = !result['developer.menu.enabled'];
          }, function(error) {
            console.error(error);
          });
      } else {
        return Promise.resolve();
      }
    },

    // To delay the show/hide in root panel will cause extra screen reflow,
    // it can be checked by Toggle on Developer > Flash Repainted Area.
    init: function root_init(panel) {
      this._panel = panel;
      // Load the necessary scripts after the UI update
      setTimeout(this._loadScripts);

      // Show NFC panel when supported
      var nfcItem = panel.querySelector('.nfc-settings');
      nfcItem.hidden = !navigator.mozNfc;

      // Show proper SIM panel
      this._showSimItems();
      // Show developer panel when necessary
      this._showDeveloperMenuItem();
    }
  };

  return function ctor_root() {
    return new Root();
  };
});

/**
 * This module is used to control the background stuff when users
 * toggle on/off airplane mode checkbox.
 *
 * @module panels/root/airplane_mode_item
 */
define('panels/root/airplane_mode_item',['require','shared/airplane_mode_helper'],function(require) {
  'use strict';

  var AirplaneModeHelper = require('shared/airplane_mode_helper');

  /**
   * @alias module:panels/root/airplane_mode_item
   * @class AirplaneModeItem
   * @param {HTMLElement} element the checkbox for airplane mode
   * @returns {AirplaneModeItem}
   */
  function AirplaneModeItem(element) {
    this._itemEnabled = false;
    this._element = element;
    this.init();
    this._boundAPMStateChange = this._onAPMStateChange.bind(this);
  }

  AirplaneModeItem.prototype = {
    /**
     * The value indicates whether the module is responding.
     *
     * @access public
     * @memberOf AirplaneModeItem.prototype
     * @type {Boolean}
     */
    set enabled(value) {
      if (this._itemEnabled === value) {
        return;
      } else {
        this._itemEnabled = value;
        if (this._itemEnabled) {
          AirplaneModeHelper.addEventListener('statechange',
            this._boundAPMStateChange);
        } else {
          AirplaneModeHelper.removeEventListener('statechange',
            this._boundAPMStateChange);
        }
      }
    },

    /**
     * The value indicates whether the module is responding.
     *
     * @access public
     * @memberOf AirplaneModeItem.prototype
     * @type {Boolean}
     */
    get enabled() {
      return this._itemEnabled;
    },

    /**
     * This function is used to reflect current status of APM to checkbox
     *
     * @access private
     * @memberOf AirplaneModeItem.prototype
     * @param {String} status current status of APM
     * @type {Function}
     */
    _onAPMStateChange: function ami_onAPMStateChange(status) {
      if (status === 'enabled' || status === 'disabled') {
        this._element.checked = (status === 'enabled') ? true : false;
        this._element.disabled = false;
      } else {
        this._element.disabled = true;
      }
    },

    /**
     * Initialize function
     *
     * @access public
     * @memberOf AirplaneModeItem.prototype
     * @type {Function}
     */
    init: function ami_init() {
      AirplaneModeHelper.ready(function() {
        // handle change on radio
        this._element.addEventListener('change', () => {
          this._element.setAttribute('disabled', true);
          AirplaneModeHelper.setEnabled(this._element.checked);
        });

        // initial status
        var status = AirplaneModeHelper.getStatus();
        this._element.checked = (status === 'enabled') ? true : false;
        // Bug 1217717 disable the Airplane mode interaction
        // before the wifi panel is ready
        this._element.disabled = true;
        window.addEventListener('wificontext-ready', this);
      }.bind(this));
    },

    handleEvent: function ami_handleEvent(evt) {
      switch (evt.type) {
        // Bug 1217717 enable the Airplane mode interaction
        // once the wifi panel is ready
        case 'wificontext-ready':
          window.removeEventListener('wificontext-ready', this);
          this._element.disabled = false;
          break;
      }
    }
  };

  return function ctor_airplane_mode_item(element) {
    return new AirplaneModeItem(element);
  };
});

/**
 * This module is used to show/hide themes menuItem based on the number of
 * current installed themes.
 *
 * @module ThemesItem
 */
define('panels/root/themes_item',['require','modules/apps_cache'],function(require) {
  'use strict';

  var AppsCache = require('modules/apps_cache');

  function ThemesItem(element) {
    this._enabled = false;
    this._element = element; 
    this._themeCount = 0;
    this._boundUpdateThemes = this._updateThemes.bind(this);
    this.init();
  }

  ThemesItem.prototype = {
    /**
     * Set current status of themesItem
     *
     * @access public
     * @param {Boolean} enabled
     * @memberOf ThemesItem
     */
    set enabled(enabled) {
      if (this._enabled === enabled) {
        return;
      } else {
        this._enabled = enabled;
        if (this._enabled) {
          this._updateThemeSectionVisibility();
        }
      }
    },

    /**
     * Get current status of themesItem
     *
     * @access public
     * @memberOf ThemesItem
     */
    get enabled() {
      return this._enabled;
    },

    /**
     * Initialization
     *
     * @access private
     * @memberOf ThemesItem
     * @return {Promise}
     */
    init: function() {
      var self = this;
      AppsCache.addEventListener('install', this._boundUpdateThemes);
      AppsCache.addEventListener('uninstall', this._boundUpdateThemes);
      return AppsCache.apps().then(function(apps) {
        apps.some(function(app) {
          if (self._isThemeApp(app)) {
            self._themeCount += 1;
          }
        });
        self._updateThemeSectionVisibility();
      });
    },

    /**
     * Check whether this app is theme app
     *
     * @param {Object} app
     * @returns {Boolean}
     * @memberOf ThemesItem
     */
    _isThemeApp: function(app) {
      var manifest = app.manifest || app.updateManifest;
      return manifest.role === 'theme';
    },

    /**
     * We have to update theme count based on incoming evt and
     * decide to show/hide or not.
     *
     * @param {Object} evt
     * @memberOf ThemesItem
     */
    _updateThemes: function(evt) {
      var app = evt && evt.application;
      var type = evt.type;

      if (this._isThemeApp(app)) {
        if (type === 'install') {
          this._themeCount += 1;
        } else if (type === 'uninstall') {
          this._themeCount -= 1;
        }
        this._updateThemeSectionVisibility();
      }
    },

    /**
     * Update theme section visibility based on _themeCount
     *
     * @memberOf ThemesItem
     */
    _updateThemeSectionVisibility: function() {
      this._element.hidden = (this._themeCount < 2);
    }
  };

  return function ctor_themesItem(element) {
    return new ThemesItem(element);
  };
});

/**
 * This module is used to show/hide addon menuItem based on the number of
 * current installed addons.
 *
 * @module AddonsItem
 */
define('panels/root/addons_item',['require','modules/addon_manager'],function(require) {
  'use strict';

  var AddonManager = require('modules/addon_manager');

  function AddonsItem(element) {
    this._enabled = false;
    this._element = element;
    this.init();
  }

  AddonsItem.prototype = {
    /**
     * Set current status of addonsItem
     *
     * @access public
     * @param {Boolean} enabled
     * @memberOf AddonsItem
     */
    set enabled(enabled) {
      if (this._enabled === enabled) {
        return;
      } else {
        this._enabled = enabled;
        if (this._enabled) {
          this._updateAddonSectionVisibility();
        }
      }
    },

    /**
     * Get current status of addonsItem
     *
     * @access public
     * @memberOf AddonsItem
     */
    get enabled() {
      return this._enabled;
    },

    /**
     * Initialization
     *
     * @access private
     * @memberOf AddonsItem
     * @return {Promise}
     */
    init: function() {
      var _handleEvent = this._updateAddonSectionVisibility.bind(this);
      AddonManager.addons.observe('insert', _handleEvent);
      AddonManager.addons.observe('remove', _handleEvent);
      AddonManager.addons.observe('reset', _handleEvent);

      this._updateAddonSectionVisibility();
    },

    /**
     * Update addon section visibility based on _addonCount
     *
     * @memberOf AddonsItem
     */
    _updateAddonSectionVisibility: function() {
      this._element.hidden = AddonManager.length === 0;
    }
  };

  return function(element) {
    return new AddonsItem(element);
  };
});

define('panels/root/stk_item',['require','shared/stk_helper'],function(require) {
  'use strict';
  var STKHelper = require('shared/stk_helper');

  function STKItem(elements) {
    this._elements = elements;
    this.init();
  }

  STKItem.prototype.init = function() {
    var iccLoaded = false;
    var self = this;
    function loadIccPage(callback) {
      callback = (typeof callback === 'function') ? callback : function() {};
      if (iccLoaded) {
        return callback();
      }
      Settings.currentPanel = '#icc';
      window.addEventListener('iccPageLoaded',
        function oniccPageLoaded(event) {
          iccLoaded = true;
          callback();
        });
    }

    function executeIccCmd(iccMessage) {
      if (!iccMessage) {
        return;
      }

      // Clear cache
      var reqIccData = window.navigator.mozSettings.createLock().set({
        'icc.data': null
      });
      reqIccData.onsuccess = function icc_getIccData() {
        window.DUMP('ICC Cache cleared');
      };

      // Open ICC section
      window.DUMP('ICC message to execute: ', iccMessage);
      loadIccPage(function() {
        var event = new CustomEvent('stkasynccommand', {
          detail: { 'message': iccMessage }
        });
        window.dispatchEvent(event);
      });
    }

    setTimeout(function updateStkMenu() {
      window.DUMP('Showing STK main menu');
      // XXX https://bugzilla.mozilla.org/show_bug.cgi?id=844727
      // We should use Settings.settingsCache first
      var settings = navigator.mozSettings;
      var lock = settings.createLock();

      function showStkEntries(menu) {
        window.DUMP('STK cached menu: ', menu);
        if (!menu || typeof menu !== 'object' ||
          Object.keys(menu).length === 0) {
            window.DUMP('No STK available - exit');
            self._elements.iccMainHeader.hidden = true;
            self._elements.iccEntries.hidden = true;
            return;
        }

        // Clean current entries
        self._elements.iccEntries.innerHTML = '';
        self._elements.iccMainHeader.hidden = true;
        self._elements.iccEntries.hidden = true;

        // update and show the entry in settings
        Object.keys(menu).forEach(function(SIMNumber) {
          window.DUMP('STK Menu for SIM ' + SIMNumber +
            ' (' + menu[SIMNumber].iccId + ') - ', menu[SIMNumber].entries);

          var li = document.createElement('li');
          var a = document.createElement('a');
          var menuItem = menu[SIMNumber].entries;
          var icon = STKHelper.getFirstIconRawData(menuItem);

          a.id = 'menuItem-icc-' + menu[SIMNumber].iccId;
          a.className = 'menu-item menuItem-icc';
          a.href = '#icc';
          if (icon) {
            var iconContainer = document.createElement('span');
            iconContainer.appendChild(STKHelper.getIconCanvas(icon));
            iconContainer.setAttribute('aria-hidden', true);
            li.appendChild(iconContainer);
            self._elements.iccEntries.dataset.customIcon = true;
          } else {
            a.dataset.icon = 'sim-toolkit';
          }
          a.onclick = function menu_icc_onclick() {
            window.DUMP('Touched ' + menu[SIMNumber].iccId);
            loadIccPage(function() {
              var event = new CustomEvent('stkmenuselection', {
                detail: { 'menu': menu[SIMNumber] }
              });
              window.dispatchEvent(event);
            });
          };

          var span = document.createElement('span');
          var title = menu[SIMNumber].entries.title;
          span.textContent = title;
          a.appendChild(span);
          window.navigator.mozL10n.setAttributes(a, 'stkEntry', {title: title});

          if (Object.keys(menu).length > 1) {
            var small = document.createElement('small');
            small.setAttribute('data-l10n-id', 'sim' + SIMNumber);
            small.classList.add('menu-item-desc');
            small.id = 'sim-desc-' + SIMNumber;
            a.setAttribute('aria-describedby', small.id);
            a.appendChild(small);
          }

          li.appendChild(a);
          self._elements.iccEntries.appendChild(li);

          self._elements.iccMainHeader.hidden = false;
          self._elements.iccEntries.hidden = false;
        });
      }

      // Check if SIM card sends an Applications menu
      var reqApplications = lock.get('icc.applications');
      reqApplications.onsuccess = function icc_getApplications() {
        var json = reqApplications.result['icc.applications'];
        var menu = json && JSON.parse(json);
        showStkEntries(menu);
      };

      settings.addObserver('icc.applications',
        function icc_getApplications(event) {
          var json = event.settingValue;
          var menu = json && JSON.parse(json);
          window.DUMP('STK Settings.currentPanel ' +  Settings.currentPanel);
          if (Settings && Settings.currentPanel === '#icc') {
             Settings.currentPanel = '#root';
          }
          showStkEntries(menu);
        });

      // Check if there are pending STK commands
      var reqIccData = lock.get('icc.data');
      reqIccData.onsuccess = function icc_getIccData() {
        var cmd = reqIccData.result['icc.data'];
        if (cmd) {
          window.DUMP('ICC async command (launcher)');
          executeIccCmd(JSON.parse(cmd));
        }
      };

      settings.addObserver('icc.data', function(event) {
        var value = event.settingValue;
        if (value) {
          window.DUMP('ICC async command while settings running: ', value);
          executeIccCmd(JSON.parse(value));
        }
      });
    }.bind(this));
  };

  return function ctor_stk_item(elements) {
    return new STKItem(elements);
  };
});

define('panels/root/panel',['require','modules/settings_service','modules/settings_panel','panels/root/root','panels/root/airplane_mode_item','panels/root/themes_item','panels/root/addons_item','panels/root/stk_item'],function(require) {
  'use strict';

  var SettingsService = require('modules/settings_service');
  var SettingsPanel = require('modules/settings_panel');
  var Root = require('panels/root/root');

  var AirplaneModeItem = require('panels/root/airplane_mode_item');
  var ThemesItem = require('panels/root/themes_item');
  var AddonsItem = require('panels/root/addons_item');
  var STKItem = require('panels/root/stk_item');

  var queryRootForLowPriorityItems = function(panel) {
    // This is a map from the module name to the object taken by the constructor
    // of the module.
    return {
      'BluetoothItem': panel.querySelector('.bluetooth-desc'),
      'NFCItem': {
        nfcMenuItem: panel.querySelector('.nfc-settings'),
        nfcCheckBox: panel.querySelector('#nfc-input')
      },
      'LanguageItem': panel.querySelector('.language-desc'),
      'BatteryItem': panel.querySelector('.battery-desc'),
      'FindMyDeviceItem': panel.querySelector('.findmydevice-desc'),
      'StorageUSBItem': {
        mediaStorageDesc: panel.querySelector('.media-storage-desc'),
        usbStorage: panel.querySelector('#menuItem-enableStorage'),
        usbEnabledInfoBlock: panel.querySelector('.usb-desc'),
        mediaStorageSection: panel.querySelector('.media-storage-section')
      },
      'StorageAppItem': panel.querySelector('.application-storage-desc'),
      'WifiItem': panel.querySelector('#wifi-desc'),
      'ScreenLockItem': panel.querySelector('.screenLock-desc'),
      'SimSecurityItem': panel.querySelector('.simCardLock-desc')
    };
  };

  return function ctor_root_panel() {
    var root;
    var airplaneModeItem;
    var themesItem;
    var addonsItem;
    var stkItem;

    var activityDoneButton;

    var lowPriorityRoots = null;
    var initLowPriorityItemsPromise = null;
    var initLowPriorityItems = function(rootElements) {
      if (!initLowPriorityItemsPromise) {
        initLowPriorityItemsPromise = new Promise(function(resolve) {
          require(['panels/root/low_priority_items'], resolve);
        }).then(function(itemCtors) {
          var result = {};
          Object.keys(rootElements).forEach(function(name) {
            var itemCtor = itemCtors[name];
            if (itemCtor) {
              result[name] = itemCtor(rootElements[name]);
            }
          });
          return result;
        });
      }
      return initLowPriorityItemsPromise;
    };

    return SettingsPanel({
      onInit: function rp_onInit(panel) {
        root = Root();
        root.init(panel);

        airplaneModeItem =
          AirplaneModeItem(panel.querySelector('.airplaneMode-input'));
        themesItem =
          ThemesItem(panel.querySelector('.themes-section'));
        addonsItem =
          AddonsItem(panel.querySelector('#addons-section'));
        stkItem = STKItem({
          iccMainHeader: panel.querySelector('#icc-mainheader'),
          iccEntries: panel.querySelector('#icc-entries')
        });

        activityDoneButton = panel.querySelector('#activityDoneButton');
        activityDoneButton.addEventListener('click', function() {
          SettingsService.back();
        });

        // If the device supports dsds, callSettings must be changed 'href'
        // for navigating call-iccs panel first to let users choose simcard
        var mozMobileConnections = navigator.mozMobileConnections;
        if (mozMobileConnections && mozMobileConnections.length > 1) {
          var callItem = document.getElementById('menuItem-callSettings');
          callItem.setAttribute('href', '#call-iccs');
        }

        var idleObserver = {
          time: 3,
          onidle: function() {
            navigator.removeIdleObserver(idleObserver);
            lowPriorityRoots = queryRootForLowPriorityItems(panel);
            initLowPriorityItems(lowPriorityRoots).then(function(items) {
              Object.keys(items).forEach((key) => items[key].enabled = true);
            });
          }
        };
        navigator.addIdleObserver(idleObserver);
      },
      onShow: function rp_onShow(panel) {
        airplaneModeItem.enabled = true;
        themesItem.enabled = true;
        addonsItem.enabled = true;

        if (initLowPriorityItemsPromise) {
          initLowPriorityItemsPromise.then(function(items) {
            Object.keys(items).forEach((key) => items[key].enabled = true);
          });
        }
      },
      onHide: function rp_onHide() {
        themesItem.enabled = false;
        addonsItem.enabled = false;

        if (initLowPriorityItemsPromise) {
          initLowPriorityItemsPromise.then(function(items) {
            Object.keys(items).forEach((key) => items[key].enabled = false);
          });
        }
      },
      onUninit: function rp_onUninit() {
        airplaneModeItem.enabled = false;
      }
    });
  };
});

