'use strict';
/* exported MockAllFacebookContacts */
/* exported MockLinkedContacts */

var MockLinkedContacts = {
  data: [{
    fql_result_set: [
      {
        'uid': '1xz',
        'email': 'test@test.com',
        'name': 'Pepito Grillo'
      },
      {
        'uid': '2abc',
        'email': 'test2@test2.com',
        'name': 'Alfonso Gonzo'
      }]},
      {
    fql_result_set: [{
      'uid': '5678x'
      },
      {
        'uid': '56zwt'
      },
      {
        'uid': 'kjh2389'
      },
      {
        'uid': 'aa45bb'
      }]
    }
  ]
};

var MockAllFacebookContacts = {
  data: [
    {
      'uid': '5678x',
      'email': 'beppe@grillo.it',
      'name': 'Beppe Grillo',
      'last_name': 'Grillo',
      'first_name': 'Beppe',
      'middle_name': null
    },
    {
      'uid': '56zwt',
      'email': 'test2@test2.com',
      'name': 'Herman Gonzo',
      'last_name': 'Gonzo',
      'first_name': 'Herman',
      'middle_name': null
    },
    {
      'uid': 'kjh2389',
      'email': 'angela.cuts@german.de',
      'name': 'Ángela Cuts',
      'last_name': 'Cuts',
      'first_name': 'Ángela',
      'middle_name': null
    },
    {
      'uid': 'aa45bb',
      'email': 'rudygonzalez@example.org',
      'name': 'Rudy González',
      'last_name': 'González',
      'first_name': 'Rudy',
      'middle_name': null
    }
  ]
};
